import { a as __toESM, r as require_react, t as require_jsx_runtime } from "./jsx-runtime-C_MSr2-h.js";
import { Cn as Phone, It as ALL_BLOOD_GROUPS, Ln as Heart, Sn as Plus, _n as Share2, cn as X, ln as Users, pn as Trash2, un as UserPlus } from "./index-iojd0cJp.js";
// src/utils/audioAlert.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var audioCtx = null;
function getAudioContext() {
	if (typeof window === "undefined") return null;
	const AudioContextClass = window.AudioContext || window.webkitAudioContext;
	if (!AudioContextClass) return null;
	if (!audioCtx) audioCtx = new AudioContextClass();
	if (audioCtx.state === "suspended") audioCtx.resume();
	return audioCtx;
}
/**
* Play a high-priority double-chirp emergency sound
*/
function playEmergencyChime() {
	try {
		const ctx = getAudioContext();
		if (!ctx) return;
		const now = ctx.currentTime;
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = "sine";
		osc.frequency.setValueAtTime(850, now);
		osc.frequency.exponentialRampToValueAtTime(1250, now + .15);
		osc.frequency.setValueAtTime(850, now + .2);
		osc.frequency.exponentialRampToValueAtTime(1400, now + .35);
		gain.gain.setValueAtTime(.25, now);
		gain.gain.exponentialRampToValueAtTime(.001, now + .45);
		osc.connect(gain);
		gain.connect(ctx.destination);
		osc.start(now);
		osc.stop(now + .45);
		if (typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate([
			200,
			100,
			200
		]);
	} catch (e) {}
}
// src/components/ecosystem/ThalassemiaManagerModal.tsx
var import_jsx_runtime = require_jsx_runtime();
var ThalassemiaManagerModal = ({ isOpen, onClose, lang }) => {
	const [patients, setPatients] = (0, import_react.useState)(() => {
		try {
			const saved = localStorage.getItem("bloodsearch_thalassemia_patients");
			if (saved) {
				const parsed = JSON.parse(saved);
				if (Array.isArray(parsed)) return parsed.filter((p) => p && typeof p.id === "string" && !/^th-[1-2]$/.test(p.id));
			}
		} catch {}
		return [];
	});
	const [selectedPatientId, setSelectedPatientId] = (0, import_react.useState)(() => patients[0]?.id || "");
	const [isAddingPatient, setIsAddingPatient] = (0, import_react.useState)(() => patients.length === 0);
	const [copiedReminder, setCopiedReminder] = (0, import_react.useState)(false);
	const [newName, setNewName] = (0, import_react.useState)("");
	const [newAge, setNewAge] = (0, import_react.useState)(10);
	const [newGroup, setNewGroup] = (0, import_react.useState)("B+");
	const [newHospital, setNewHospital] = (0, import_react.useState)("");
	const [newPhone, setNewPhone] = (0, import_react.useState)("");
	const [newInterval, setNewInterval] = (0, import_react.useState)(21);
	const [newHb, setNewHb] = (0, import_react.useState)(8);
	const [addingDonorForPatient, setAddingDonorForPatient] = (0, import_react.useState)(false);
	const [slotDonorName, setSlotDonorName] = (0, import_react.useState)("");
	const [slotDonorPhone, setSlotDonorPhone] = (0, import_react.useState)("");
	const [slotMonthLabel, setSlotMonthLabel] = (0, import_react.useState)("১ম মাস");
	(0, import_react.useEffect)(() => {
		try {
			localStorage.setItem("bloodsearch_thalassemia_patients", JSON.stringify(patients));
		} catch {}
	}, [patients]);
	if (!isOpen) return null;
	const currentPatient = patients.find((p) => p.id === selectedPatientId) || patients[0] || null;
	const calculateDaysRemaining = (patient) => {
		const nextDate = new Date(patient.lastTransfusionDate).getTime() + patient.transfusionIntervalDays * 24 * 3600 * 1e3;
		return Math.ceil((nextDate - Date.now()) / 864e5);
	};
	const daysRemaining = currentPatient ? calculateDaysRemaining(currentPatient) : 0;
	const isUrgent = daysRemaining <= 3;
	const handleAddPatient = (e) => {
		e.preventDefault();
		if (!newName.trim() || !newPhone.trim() || !newHospital.trim()) return;
		const newPat = {
			id: `th-${Date.now()}`,
			name: newName.trim(),
			age: Number(newAge) || 10,
			bloodGroup: newGroup,
			hospital: newHospital.trim(),
			guardianName: lang === "bn" ? "অভিভাবক" : "Guardian",
			contactPhone: newPhone.trim(),
			transfusionIntervalDays: Number(newInterval) || 21,
			lastTransfusionDate: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
			currentHb: Number(newHb) || 8,
			repeatDonors: []
		};
		setPatients((prev) => [newPat, ...prev]);
		setSelectedPatientId(newPat.id);
		setIsAddingPatient(false);
		setNewName("");
		setNewHospital("");
		setNewPhone("");
		playEmergencyChime();
	};
	const handleDeletePatient = (id) => {
		setPatients((prev) => {
			const next = prev.filter((p) => p.id !== id);
			if (selectedPatientId === id) setSelectedPatientId(next[0]?.id || "");
			return next;
		});
	};
	const handleAddRepeatDonor = (e) => {
		e.preventDefault();
		if (!currentPatient || !slotDonorName.trim() || !slotDonorPhone.trim()) return;
		const newSlot = {
			name: slotDonorName.trim(),
			phone: slotDonorPhone.trim(),
			monthSlot: slotMonthLabel.trim() || "নিয়মিত রক্তদাতা",
			confirmed: true
		};
		setPatients((prev) => prev.map((p) => p.id === currentPatient.id ? {
			...p,
			repeatDonors: [...p.repeatDonors, newSlot]
		} : p));
		setSlotDonorName("");
		setSlotDonorPhone("");
		setAddingDonorForPatient(false);
	};
	const buildReminderMessage = (patient) => `জরুরি থ্যালাসেমিয়া রিমাইন্ডার:\nরোগীর নাম: ${patient.name}\nব্লাড গ্রুপ: ${patient.bloodGroup}\nহাসপাতাল: ${patient.hospital}\nরক্ত নেওয়ার তারিখ: আগামী ${Math.max(1, daysRemaining)} দিনের মধ্যে\nবর্তমান হিমোগ্লোবিন: ${patient.currentHb} g/dL\nঅভিভাবকের নম্বর: ${patient.contactPhone}\n\nঅনুগ্রহ করে রক্তদানে এগিয়ে আসুন। BloodSearch Network BD.`;
	const handleCopyReminder = (patient) => {
		const message = buildReminderMessage(patient);
		navigator.clipboard?.writeText(message).catch(() => {});
		setCopiedReminder(true);
		setTimeout(() => setCopiedReminder(false), 2500);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-start justify-center p-2.5 sm:p-4 bg-black/80 overflow-y-auto modal-scroll-contain",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-2xl my-2 sm:my-auto rounded-3xl bg-white dark:bg-[#1e293b] text-slate-900 dark:text-white p-4 sm:p-6 shadow-2xl border border-slate-300 dark:border-slate-700 transition-all text-left",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between pb-3.5 border-b border-slate-200 dark:border-slate-800",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-11 h-11 rounded-2xl bg-gradient-to-tr from-rose-600 to-amber-600 text-white flex items-center justify-center shadow-md",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "w-5 h-5 fill-white" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-base sm:text-lg font-black text-slate-900 dark:text-white",
							children: lang === "bn" ? "থ্যালাসেমিয়া ও নিয়মিত রক্ত সঞ্চালন ট্র্যাকার" : "Thalassemia & Routine Blood Tracker"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-slate-500 dark:text-slate-400 mt-0.5",
							children: lang === "bn" ? "থ্যালাসেমিয়া ও ডায়ালাইসিস রোগীদের ব্যক্তিগত রক্তদান শিডিউল ও ডোনার পুল" : "Personal recurring transfusion schedule and rotating donor pool"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-5 h-5" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-3 flex items-center justify-between gap-2 overflow-x-auto scrollbar-none border-b border-slate-100 dark:border-slate-800/80",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-1.5 shrink-0",
						children: patients.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								setSelectedPatientId(p.id);
								setIsAddingPatient(false);
							},
							className: `px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${currentPatient?.id === p.id && !isAddingPatient ? "bg-rose-600 text-white shadow-xs" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono font-black",
								children: [
									"(",
									p.bloodGroup,
									")"
								]
							})]
						}, p.id))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setIsAddingPatient(!isAddingPatient),
						className: "px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isAddingPatient && patients.length > 0 ? lang === "bn" ? "বাতিল" : "Cancel" : lang === "bn" ? "+ নতুন রোগী যুক্ত করুন" : "+ Add Patient" })]
					})]
				}),
				isAddingPatient || !currentPatient ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleAddPatient,
					className: "py-4 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xs font-bold text-slate-800 dark:text-slate-200",
							children: lang === "bn" ? "নতুন থ্যালাসেমিয়া / ডায়ালাইসিস রোগীর তথ্য যুক্ত করুন" : "Add Thalassemia / Routine Transfusion Patient"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1",
									children: lang === "bn" ? "রোগীর নাম *" : "Patient Name *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "thalPatientName",
									type: "text",
									value: newName,
									onChange: (e) => setNewName(e.target.value),
									placeholder: lang === "bn" ? "রোগীর আসল নাম লিখুন" : "Enter patient full name",
									className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-medium",
									required: true
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1",
									children: lang === "bn" ? "ব্লাড গ্রুপ *" : "Blood Group *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									name: "thalBloodGroup",
									value: newGroup,
									onChange: (e) => setNewGroup(e.target.value),
									className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-bold",
									children: ALL_BLOOD_GROUPS.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: g,
										children: g
									}, g))
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1",
									children: lang === "bn" ? "হাসপাতাল / কেন্দ্রের নাম *" : "Hospital / Center *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "thalHospital",
									type: "text",
									value: newHospital,
									onChange: (e) => setNewHospital(e.target.value),
									placeholder: lang === "bn" ? "হাসপাতালের নাম লিখুন" : "Hospital name",
									className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-medium",
									required: true
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1",
									children: lang === "bn" ? "অভিভাবকের মোবাইল নম্বর *" : "Guardian Mobile *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "thalGuardianPhone",
									type: "tel",
									value: newPhone,
									onChange: (e) => setNewPhone(e.target.value),
									placeholder: "01XXXXXXXXX",
									className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-mono",
									required: true
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1",
									children: lang === "bn" ? "রক্ত নেওয়ার ব্যবধান" : "Transfusion Interval"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									name: "thalIntervalDays",
									value: newInterval,
									onChange: (e) => setNewInterval(Number(e.target.value)),
									className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-bold",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: 14,
											children: "১৪ দিন পর পর (14 days)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: 21,
											children: "২১ দিন পর পর (21 days)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: 28,
											children: "২৮ দিন পর পর (28 days)"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: 35,
											children: "৩৫ দিন পর পর (35 days)"
										})
									]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1",
									children: lang === "bn" ? "বর্তমান হিমোগ্লোবিন (Hb g/dL)" : "Current Hemoglobin (g/dL)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									name: "thalCurrentHb",
									type: "number",
									step: "0.1",
									value: newHb,
									onChange: (e) => setNewHb(Number(e.target.value)),
									placeholder: "8.0",
									className: "w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 text-xs font-mono"
								})] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-sm transition-colors cursor-pointer",
								children: lang === "bn" ? "রোগীর শিডিউল সংরক্ষণ করুন" : "Save Patient Schedule"
							}), patients.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setIsAddingPatient(false),
								className: "px-4 py-2.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold cursor-pointer",
								children: lang === "bn" ? "বাতিল" : "Cancel"
							})]
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-4 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `p-4 rounded-2xl border text-white shadow-md ${isUrgent ? "bg-gradient-to-r from-red-600 via-rose-600 to-rose-700 border-red-400" : "bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border-slate-700"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] font-bold text-amber-200 mb-1",
									children: [
										currentPatient.name,
										" · ",
										currentPatient.hospital
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg sm:text-xl font-black",
									children: daysRemaining <= 0 ? lang === "bn" ? "আজই রক্ত গ্রহণ প্রয়োজন!" : "Transfusion due today!" : lang === "bn" ? `আগামী ${daysRemaining} দিনের মধ্যে রক্ত প্রয়োজন` : `Next transfusion in ${daysRemaining} day(s)`
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 bg-black/30 p-3 rounded-2xl border border-white/20 shrink-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-center font-mono",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-2xl font-black text-amber-300",
												children: Math.max(0, daysRemaining)
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-slate-300 block -mt-1 font-bold",
												children: lang === "bn" ? "দিন বাকি" : "Days"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-white/40 font-bold",
											children: ":"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-center font-mono",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-2xl font-black text-white",
												children: currentPatient.bloodGroup
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-[10px] text-slate-300 block -mt-1 font-bold",
												children: lang === "bn" ? "গ্রুপ" : "Group"
											})]
										})
									]
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
								className: "text-xs font-bold text-slate-900 dark:text-white",
								children: [
									"Hb: ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-rose-600",
										children: [currentPatient.currentHb, " g/dL"]
									}),
									" ",
									"· ",
									lang === "bn" ? "ব্যবধান" : "Cycle",
									": ",
									currentPatient.transfusionIntervalDays,
									" ",
									lang === "bn" ? "দিন" : "days"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-slate-500 font-mono mt-0.5",
								children: currentPatient.contactPhone
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: `tel:${currentPatient.contactPhone}`,
									className: "px-3 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang === "bn" ? "কল" : "Call" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => handleDeletePatient(currentPatient.id),
									className: "p-2 rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 cursor-pointer",
									title: "Remove Patient",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "w-4 h-4" })
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "w-3.5 h-3.5 text-rose-600" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
											lang === "bn" ? "রক্তদাতা রোটেশন পুল" : "Rotating Donor Pool",
											" (",
											currentPatient.repeatDonors.length,
											")"
										] })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setAddingDonorForPatient(!addingDonorForPatient),
										className: "text-xs font-bold text-rose-600 dark:text-rose-400 inline-flex items-center gap-1 cursor-pointer",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "w-3.5 h-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang === "bn" ? "ডোনার যুক্ত করুন" : "Add Donor" })]
									})]
								}),
								addingDonorForPatient && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: handleAddRepeatDonor,
									className: "p-3 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "slotDonorName",
											type: "text",
											required: true,
											placeholder: lang === "bn" ? "ডোনারের নাম" : "Donor Name",
											value: slotDonorName,
											onChange: (e) => setSlotDonorName(e.target.value),
											className: "px-3 py-2 rounded-lg bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-xs"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "slotDonorPhone",
											type: "tel",
											required: true,
											placeholder: "01XXXXXXXXX",
											value: slotDonorPhone,
											onChange: (e) => setSlotDonorPhone(e.target.value),
											className: "px-3 py-2 rounded-lg bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-xs font-mono"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												name: "slotMonthLabel",
												type: "text",
												placeholder: lang === "bn" ? "মাস (যেমন: ১ম মাস)" : "Month Slot",
												value: slotMonthLabel,
												onChange: (e) => setSlotMonthLabel(e.target.value),
												className: "flex-1 min-w-0 px-2.5 py-2 rounded-lg bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-xs"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "submit",
												className: "px-3 py-2 rounded-lg bg-emerald-600 text-white font-bold text-xs cursor-pointer",
												children: "Save"
											})]
										})
									]
								}),
								currentPatient.repeatDonors.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "p-4 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 text-xs text-slate-500 text-center",
									children: lang === "bn" ? "এই রোগীর জন্য এখনো কোনো নির্ধারিত রোটেশন ডোনার যুক্ত করা হয়নি।" : "No rotating donors added for this patient yet."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
									children: currentPatient.repeatDonors.map((donor, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "p-3 rounded-xl bg-white dark:bg-[#0f172a] border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h5", {
											className: "font-bold text-xs text-slate-900 dark:text-white",
											children: donor.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-[11px] text-slate-500 font-mono block",
											children: [
												donor.monthSlot,
												" · ",
												donor.phone
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: `tel:${donor.phone}`,
											className: "p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 cursor-pointer",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "w-3.5 h-3.5" })
										})]
									}, idx))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "pt-2 flex flex-col sm:flex-row items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: `https://wa.me/?text=${encodeURIComponent(buildReminderMessage(currentPatient))}`,
								target: "_blank",
								rel: "noopener noreferrer",
								onClick: () => handleCopyReminder(currentPatient),
								className: "w-full sm:flex-1 py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "w-4 h-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copiedReminder ? lang === "bn" ? "✓ রিমাইন্ডার কপি হয়েছে ও হোয়াটসঅ্যাপ খুলছে!" : "✓ Reminder Copied & Opening WhatsApp!" : lang === "bn" ? "হোয়াটসঅ্যাপে রিমাইন্ডার পাঠান" : "Send Reminder via WhatsApp" })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: onClose,
								className: "w-full sm:w-auto px-6 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold text-xs cursor-pointer",
								children: lang === "bn" ? "বন্ধ করুন" : "Close"
							})]
						})
					]
				})
			]
		})
	});
};
export { ThalassemiaManagerModal };
